//При клике на icon бургера +класс для иконки и body выезжающего меню
const iconMenu = document.querySelector('.burger-icon');
const menuBody = document.querySelector('.header__btm');
function toggleMenuClases() {
	iconMenu.classList.toggle('_active');
	menuBody.classList.toggle('_active');
	document.body.classList.toggle('_lock');
}
iconMenu.addEventListener('click', toggleMenuClases);
menuBody.addEventListener('click', function (event) {
	let target = event.target.closest('li');
	if (!target) return;
	toggleMenuClases();
})